text = input("Enter Title: ")

length = len(text)
print("The length of the title: ", length)

