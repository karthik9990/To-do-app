password = input("Enter Password: ")

while password != "pass123":
    password = input("Enter Password")
print("Password was correct!")